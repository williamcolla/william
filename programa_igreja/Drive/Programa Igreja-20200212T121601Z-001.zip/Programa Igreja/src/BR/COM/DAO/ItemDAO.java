/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BR.COM.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import BR.COM.DTO.ItemDTO;
import BR.COM.DAO.Conexao;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author beatr
 */
public class ItemDAO {
    private Connection con;
    
    
     public ResultSet listaBusca(ItemDTO objItemdto){
    
        try{
        
            String comando="Select IT.id_item, IT.nome, IT.qtd,I.nome_igreja, C.nome_categoria, IT.obs from item IT inner join igreja I on IT.id_igreja = I.id_igreja inner join categoria C on IT.id_categoria=C.id_categoria;";
            
            con=Conexao.conectaBD();
            PreparedStatement pstm=con.prepareStatement(comando);
            
            ResultSet rs= pstm.executeQuery();
            System.out.println(comando);
            return rs;
            
            
            
        }catch(Exception ex){
        
            System.out.println(ex.getMessage());
            return null;
        }
    
    
    }
     
     public ResultSet FiltraBusca(ItemDTO objItemdto){
           try{
        
            String comando=" Select IT.id_item, IT.nome, I.nome_igreja, S.nome_status, IT.obs from item IT inner join igreja I on IT.id_igreja = I.id_igreja inner join status S on IT.id_status=S.Id_status where IT.nome like '%"+ objItemdto.getPesquisa()+"%' or I.nome_igreja like '%"+ objItemdto.getPesquisa()+"%' or S.nome_status like '%"+ objItemdto.getPesquisa()+"%' order by IT.nome";
                                                                                                                                          
            
            con=Conexao.conectaBD();
            PreparedStatement pstm=con.prepareStatement(comando);
            
            ResultSet rs= pstm.executeQuery();
            System.out.println(comando);
            return rs;
            
            
            
        }catch(Exception ex){
        
            System.out.println(ex.getMessage());
            return null;
        }
    
     }
     
     public boolean ExcluirItem(ItemDTO objitemdto) { 
        try { 
            Conexao.conectaBD(); 
            Statement stmt = Conexao.conectaBD().createStatement(); 
            String comando = "DELETE FROM item where id_item = " + objitemdto.getId();     
            System.out.println(comando); 
            stmt.execute(comando); //retorna true ou false 
            Conexao.conectaBD().commit();  //esta comitando e efeuando gravacao no banco 
            Conexao.conectaBD().close(); 
            return true; 
        } catch (Exception e) { 
            System.out.println(e.getMessage()); 
            return false; 
        } 
    } 
           public ResultSet pesquisaigreja(){
          try{
              Conexao.conectaBD();
              Statement stmt = Conexao.conectaBD().createStatement();
              String comando = "SELECT * FROM igreja ORDER BY nome_igreja;";
              System.out.println(comando);
              return stmt.executeQuery(comando);
      }catch (Exception e){
          System.out.println(e.getMessage());
          return null;
      }
              
      }
           public ResultSet pesquisacategoria(){
          try{
              Conexao.conectaBD();
              Statement stmt = Conexao.conectaBD().createStatement();
              String comando = "SELECT * FROM categoria ORDER BY nome_categoria";
              System.out.println(comando);
              return stmt.executeQuery(comando);
      }catch (Exception e){
          System.out.println(e.getMessage());
          return null;
      }
              
      }
            public boolean InserirItem(ItemDTO objitemdto) { 
        try { 
            String comando = "insert into item (nome, id_igreja, id_categoria, obs, qtd) values (?,?,?,?,?)"; 
 
            con = Conexao.conectaBD(); 
            PreparedStatement pstm = con.prepareStatement(comando); 
 
            pstm.setString(1, objitemdto.getNome()); 
            pstm.setString(2, String.valueOf(objitemdto.getId_igreja()));
            pstm.setString(3, String.valueOf(objitemdto.getId_categoria()));
            pstm.setString(4, objitemdto.getObs());
            pstm.setInt(5, objitemdto.getQtd());
            
 
            pstm.execute(); 
            System.out.println(comando); 
            pstm.close(); 
            return true; 
        } catch (SQLException ex) { 
            System.out.println(ex.getMessage()); 
            return false; 
        } 
    
}
}
