/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BR.COM.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author beatr
 */
public class Conexao {
      public static Connection conectaBD(){
    
        Connection conn=null;
        
        try{
        
            
            String url="jdbc:mysql://localhost/igreja?user=root&password=";
            
            conn=DriverManager.getConnection(url);
            
        
        }catch(SQLException e){
        
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
        
        return conn;
    }
}
