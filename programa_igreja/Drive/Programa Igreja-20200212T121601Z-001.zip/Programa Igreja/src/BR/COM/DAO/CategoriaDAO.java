/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BR.COM.DAO;

import BR.COM.DTO.CategoriaDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author sarah
 */
public class CategoriaDAO {
    private Connection con;
    
            public boolean InserirCategoria(CategoriaDTO categoriadto) { 
        try { 
            String comando = "insert into CATEGORIA (nome_categoria) values (?)"; 
 
            con = Conexao.conectaBD(); 
            PreparedStatement pstm = con.prepareStatement(comando); 
 
            pstm.setString(1, categoriadto.getNome()); 
            
            pstm.execute(); 
            System.out.println(comando); 
            pstm.close(); 
            return true; 
        } catch (SQLException ex) { 
            System.out.println(ex.getMessage()); 
            return false; 
        } 
    
}
            
               public boolean AlterarCategoria(CategoriaDTO categoriadto)
         {
             try
                     {
                         Conexao.conectaBD();
                         Statement stmt = Conexao.conectaBD().createStatement();
                         
                         String comando="UPDATE CATEGORIA SET nome_categoria = '" + categoriadto.getNome() + "' WHERE id_categoria = " + categoriadto.getCod();
                              
                         stmt.execute(comando);
                         
                         Conexao.conectaBD().commit();
                         
                         Conexao.conectaBD().close();
                         return true;
                     }
             catch (Exception e)
                     {
                         System.out.println(e.getMessage());
                         return false;   
                     }
               
         }

   public ResultSet listaBusca(CategoriaDTO categoriadto)
    {
        try
        {
            String comando = "SELECT id_categoria, nome_categoria FROM categoria;";
            
            con = Conexao.conectaBD();
            PreparedStatement pstm = con.prepareStatement(comando);
            
            ResultSet rs = pstm.executeQuery();

            return rs;
        }
        
        catch (Exception ex)
                {
                    System.out.println(ex.getMessage());
                    return null;
                }
    }
   
    public boolean ExcluirCategoria(CategoriaDTO categoriadto)
   {
       try
       {
           Conexao.conectaBD();
           Statement stmt = Conexao.conectaBD().createStatement();
           String comando = "DELETE FROM categoria WHERE id_categoria =" + categoriadto.getCod();
           
           stmt.execute(comando);
           Conexao.conectaBD().close();
           return true;
          
       }
       
       catch (Exception e)
       {
           System.out.println(e.getMessage());
           return false;
           
       }
   }
}
