/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BR.COM.DTO;

/**
 *
 * @author beatr
 */
public class ItemDTO {

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    /**
     * @return the id_igreja
     */
    public int getId_igreja() {
        return id_igreja;
    }

    /**
     * @param id_igreja the id_igreja to set
     */
    public void setId_igreja(int id_igreja) {
        this.id_igreja = id_igreja;
    }

    /**
     * @return the id_status
     */
    public int getId_status() {
        return id_status;
    }

    /**
     * @param id_status the id_status to set
     */
    public void setId_status(int id_status) {
        this.id_status = id_status;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the igreja
     */
    public String getIgreja() {
        return igreja;
    }

    /**
     * @param igreja the igreja to set
     */
    public void setIgreja(String igreja) {
        this.igreja = igreja;
    }

    /**
     * @return the Status
     */
    public String getStatus() {
        return Status;
    }

    /**
     * @param Status the Status to set
     */
    public void setStatus(String Status) {
        this.Status = Status;
    }
    private int id;
    private String nome;
    private String igreja;
    private String Status;
    private String pesquisa;
    private String obs;
    private int qtd;
    private String categoria;
    private int id_igreja;
    private int id_status;
    private int id_categoria;

    /**
     * @return the pesquisa
     */
    public String getPesquisa() {
        return pesquisa;
    }

    /**
     * @param pesquisa the pesquisa to set
     */
    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }

    /**
     * @return the obs
     */
    public String getObs() {
        return obs;
    }

    /**
     * @param obs the obs to set
     */
    public void setObs(String obs) {
        this.obs = obs;
    }
}
